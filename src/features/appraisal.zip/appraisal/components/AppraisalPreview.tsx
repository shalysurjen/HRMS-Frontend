import { RatingInput } from "@/features/appraisal/components/RatingInput";
import { EmployeeInfoCard } from "@/features/appraisal/components/EmployeeInfoCard";
import { StatusBadge } from "@/features/appraisal/components/StatusBadge";
import type { AppraisalDetail, AnswerDTO } from "@/features/appraisal/types/appraisal";
import {
  HiOutlineArrowLeft, HiOutlineCheckCircle, HiOutlineXCircle,
  HiOutlineMegaphone, HiOutlineStar,
} from "react-icons/hi2";

const SUGGESTION_SECTION = "Suggestions";

// ─────────────────────────────────────────────────────────────────────────────
// AppraisalPreview
//
// Single-scroll read-only preview shown BEFORE final submit/approve/publish.
// Displayed after clicking "Submit" / "Approve & Forward" / "Publish".
//
// Props:
//   detail          → full appraisal detail from API
//   answers         → local draft answers (employee) OR questionRemarks (reviewer)
//   overallRemark   → reviewer's overall remark (undefined for employee)
//   approverLevel   → "EMPLOYEE" | "L1" | "L2"
//   actionLabel     → text on the confirm button
//   onCancel        → go back to the form
//   onConfirm       → actually submit/approve/publish
//   saving          → disable buttons while API call in progress
// ─────────────────────────────────────────────────────────────────────────────

interface ReviewerRemarkEntry {
  remarkText: string;
  revisedRating?: number;
}

interface Props {
  detail:        AppraisalDetail;
  // Employee: local draft answers map; Reviewer: questionRemarks map
  answers?:      Record<number, AnswerDTO>;
  remarks?:      Record<number, ReviewerRemarkEntry>;
  overallRemark?: string;
  approverLevel: "EMPLOYEE" | "L1" | "L2";
  actionLabel:   string;
  actionColor?:  "teal" | "indigo" | "rose";
  onCancel:      () => void;
  onConfirm:     () => void;
  saving:        boolean;
}

export const AppraisalPreview = ({
  detail, answers, remarks, overallRemark,
  approverLevel, actionLabel, actionColor = "teal",
  onCancel, onConfirm, saving,
}: Props) => {

  const colorMap = {
    teal:   "bg-teal-600 hover:bg-teal-700 shadow-teal-200",
    indigo: "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200",
    rose:   "bg-rose-600 hover:bg-rose-700 shadow-rose-200",
  };

  return (
    <div className="max-w-3xl mx-auto py-6 px-4 space-y-6">

      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="flex items-center gap-1.5 text-slate-500 hover:text-slate-800 text-sm font-medium transition-colors"
          >
            <HiOutlineArrowLeft size={16} /> Back to Form
          </button>
          <span className="text-slate-200">|</span>
          <p className="text-sm font-bold text-slate-700">Preview</p>
          <StatusBadge status={detail.status} />
        </div>

        {/* Review badge */}
        <span className="text-xs bg-amber-50 border border-amber-200 text-amber-700 font-bold px-3 py-1.5 rounded-full">
          📋 Please review before submitting
        </span>
      </div>

      {/* ── Employee info ───────────────────────────────────────────────────── */}
      <EmployeeInfoCard detail={detail} />

      {/* ── Overall avg (employee preview) ──────────────────────────────────── */}
      {approverLevel === "EMPLOYEE" && (() => {
        const ratedQs = detail.sections
          .filter(s => s.sectionName !== SUGGESTION_SECTION)
          .flatMap(s => s.questions)
          .filter(q => answers?.[q.questionId]?.selfRating != null);
        if (!ratedQs.length) return null;
        const avg = ratedQs.reduce((acc, q) => acc + (answers![q.questionId].selfRating ?? 0), 0) / ratedQs.length;
        return (
          <div className="flex items-center gap-3 bg-indigo-50 border border-indigo-200 rounded-xl px-4 py-2.5 w-fit">
            <HiOutlineStar size={16} className="text-indigo-500" />
            <span className="text-xs font-bold text-indigo-700">
              Overall Self Rating Avg: {Math.round(avg * 100) / 100} / 5.0
            </span>
          </div>
        );
      })()}

      {/* ── Reviewer overall remark ──────────────────────────────────────────── */}
      {approverLevel !== "EMPLOYEE" && overallRemark && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
            Your Overall Remark
          </p>
          <p className="text-sm text-slate-700">{overallRemark}</p>
        </div>
      )}

      {/* ── L1 summary — visible in L2 preview ──────────────────────────────── */}
      {approverLevel === "L2" && (
        <div className="bg-teal-50 border border-teal-200 rounded-2xl p-4 space-y-2">
          <p className="text-xs font-bold text-teal-600 uppercase tracking-wider">
            First Approver (L1) — {detail.firstApproverName ?? detail.firstApproverId ?? "—"}
          </p>
          {detail.l1OverallRemark && (
            <div className="bg-white border border-teal-100 rounded-xl p-3">
              <p className="text-[10px] font-bold text-teal-500 uppercase tracking-wider mb-1">L1 Overall Remark</p>
              <p className="text-sm text-teal-800">{detail.l1OverallRemark}</p>
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          ALL SECTIONS — single scroll, read-only
      ══════════════════════════════════════════════════════════════════════ */}
      {detail.sections.map((sec, sIdx) => {
        const isSuggestionSec = sec.sectionName === SUGGESTION_SECTION;

        return (
          <div key={sIdx} className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">

            {/* Section header */}
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-slate-800">{sec.sectionName}</h2>
                <p className="text-xs text-slate-400 mt-0.5">{sec.questions.length} questions</p>
              </div>
              {sec.sectionAvgRating != null && !isSuggestionSec && (
                <span className="text-xs font-bold bg-teal-50 border border-teal-200 text-teal-700 px-3 py-1 rounded-full">
                  ⭐ {sec.sectionAvgRating} / 5.0
                </span>
              )}
            </div>

            {/* Questions */}
            <div className="divide-y divide-slate-100">
              {sec.questions.map((q, qIdx) => {
                const isOptional  = !q.isRequired;
                const ans         = answers?.[q.questionId];
                const remark      = remarks?.[q.questionId];

                // L1 / L2 existing remarks on the question
                const l1Remark    = q.revisedRemarks ?? q.l1Remark;
                const l1Rating    = q.revisedRating  ?? q.l1RevisedRating;
                const l2Remark    = q.finalRemarks   ?? q.l2Remark;
                const l2Rating    = q.finalRating    ?? q.l2RevisedRating;

                return (
                  <div key={q.questionId} className="px-5 py-4 space-y-3">

                    {/* Question label */}
                    <div className="flex items-start gap-2">
                      <span className="text-xs font-black text-indigo-400 shrink-0 mt-0.5">
                        {String(qIdx + 1).padStart(2, "0")}
                      </span>
                      <span className="text-sm font-semibold text-slate-800">
                        {q.questionText}
                        {isOptional
                          ? <span className="text-slate-300 text-xs font-normal ml-1">(optional)</span>
                          : <span className="text-rose-400 ml-1">*</span>
                        }
                      </span>
                    </div>

                    {/* ── EMPLOYEE mode: show self-answer + self-rating ── */}
                    {approverLevel === "EMPLOYEE" && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                            Your Answer
                          </p>
                          <p className="text-sm text-slate-700 whitespace-pre-wrap">
                            {ans?.answerText || <span className="italic text-slate-300">—</span>}
                          </p>
                        </div>
                        {!isSuggestionSec && (
                          <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-3">
                            <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider mb-2">
                              Self Rating
                            </p>
                            {ans?.selfRating != null
                              ? <RatingInput value={ans.selfRating} readonly />
                              : <p className="text-xs text-slate-300 italic">Not rated</p>
                            }
                          </div>
                        )}
                      </div>
                    )}

                    {/* ── REVIEWER mode: show employee answer + self-rating + new remark ── */}
                    {approverLevel !== "EMPLOYEE" && (
                      <>
                        {/* Employee answer + self rating */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                              Employee Answer
                            </p>
                            <p className="text-sm text-slate-700 whitespace-pre-wrap">
                              {q.answerText || <span className="italic text-slate-300">No answer</span>}
                            </p>
                          </div>
                          {!isSuggestionSec && (
                            <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-3">
                              <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider mb-2">
                                Self Rating
                              </p>
                              {q.selfRating != null
                                ? <RatingInput value={q.selfRating} readonly />
                                : <p className="text-xs text-slate-300 italic">Not rated</p>
                              }
                            </div>
                          )}
                        </div>

                        {/* L1 existing remark — visible to L2 */}
                        {approverLevel === "L2" && (l1Remark || l1Rating != null) && (
                          <div className="bg-teal-50 border border-teal-100 rounded-xl p-3">
                            <p className="text-[10px] font-bold text-teal-500 uppercase tracking-wider mb-1">
                              Manager Remark (L1)
                            </p>
                            {l1Remark && <p className="text-sm text-teal-800 mb-2">{l1Remark}</p>}
                            {!isSuggestionSec && l1Rating != null && (
                              <RatingInput value={l1Rating} readonly />
                            )}
                          </div>
                        )}

                        {/* Reviewer's NEW remark (what they just filled) */}
                        {remark && (remark.remarkText || remark.revisedRating != null) && (
                          <div className={`border rounded-xl p-3 ${
                            approverLevel === "L1"
                              ? "bg-teal-50 border-teal-200"
                              : "bg-purple-50 border-purple-200"
                          }`}>
                            <p className={`text-[10px] font-bold uppercase tracking-wider mb-1 ${
                              approverLevel === "L1" ? "text-teal-500" : "text-purple-500"
                            }`}>
                              Your Remark ({approverLevel})
                            </p>
                            {remark.remarkText && (
                              <p className={`text-sm mb-2 ${
                                approverLevel === "L1" ? "text-teal-800" : "text-purple-800"
                              }`}>
                                {remark.remarkText}
                              </p>
                            )}
                            {!isSuggestionSec && remark.revisedRating != null && (
                              <>
                                <p className={`text-[10px] font-bold uppercase tracking-wider mb-1.5 ${
                                  approverLevel === "L1" ? "text-teal-400" : "text-purple-400"
                                }`}>
                                  Revised Rating
                                </p>
                                <RatingInput value={remark.revisedRating} readonly />
                              </>
                            )}
                          </div>
                        )}

                        {/* No remark filled for required question */}
                        {q.isRequired && !remark?.remarkText && !remark?.revisedRating && (
                          <div className="bg-slate-50 border border-dashed border-slate-200 rounded-xl p-3">
                            <p className="text-xs text-slate-300 italic">No remark added</p>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}

      {/* ── Spacer for sticky bar ──────────────────────────────────────────── */}
      <div className="h-4" />

      {/* ══════════════════════════════════════════════════════════════════════
          STICKY BOTTOM BAR — Cancel + Confirm Submit
      ══════════════════════════════════════════════════════════════════════ */}
      <div className="sticky bottom-4 z-20">
        <div className="bg-white border border-slate-200 rounded-2xl px-5 py-4 shadow-xl flex items-center justify-between gap-3 flex-wrap">

          <div className="flex flex-col">
            <p className="text-xs font-bold text-slate-700">Ready to submit?</p>
            <p className="text-[11px] text-slate-400">Review your answers above before confirming.</p>
          </div>

          <div className="flex gap-3">
            {/* Cancel → back to form */}
            <button
              onClick={onCancel}
              disabled={saving}
              className="flex items-center gap-2 px-5 py-3 rounded-xl border border-slate-200 text-sm font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-40 transition-all"
            >
              <HiOutlineXCircle size={16} /> Cancel
            </button>

            {/* Confirm Submit */}
            <button
              onClick={onConfirm}
              disabled={saving}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl text-white text-sm font-bold shadow-lg disabled:opacity-50 transition-all ${colorMap[actionColor]}`}
            >
              {approverLevel === "L2"
                ? <HiOutlineMegaphone size={16} />
                : <HiOutlineCheckCircle size={16} />
              }
              {saving ? "Submitting..." : actionLabel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};